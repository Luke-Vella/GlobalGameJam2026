=====================================================
The Complete UI Sound Effects Library
=====================================================

Publisher: CelerisLab
Support: apricots.business1@gmail.com
Version: 1.0.1

-----------------------------------------------------

Thank you for purchasing The Complete UI Sound Effects Library! 

We are confident this collection will save you time and help you create a polished and satisfying user experience for your players.

All sounds are provided as high-quality, game-ready files:
- Format: WAV
- Sample Rate: 48kHz
- Bit Depth: 24-bit

This ReadMe file can be safely deleted to keep your project clean.

Your feedback is incredibly valuable. If you have a moment, please consider leaving a review on the Asset Store.

Best of luck with your project!